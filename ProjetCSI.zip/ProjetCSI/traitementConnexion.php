<?php
	$bdd = pg_connect("host=localhost port=5432 dbname=script user=postgres password=admin");
?>